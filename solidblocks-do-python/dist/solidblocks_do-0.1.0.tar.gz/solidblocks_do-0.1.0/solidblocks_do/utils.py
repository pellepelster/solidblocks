import os


def current_dir():
    return os.path.dirname(os.path.realpath(__file__))
