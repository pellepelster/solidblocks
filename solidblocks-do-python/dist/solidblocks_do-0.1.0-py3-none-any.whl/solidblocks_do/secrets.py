import os

from solidblocks_do.command import command_run_interactive, command_exec


def pass_env(secret_store):
    if secret_store is None:
        secret_store = f"{os.getcwd()}/secrets"
    return {"PASSWORD_STORE_DIR": secret_store}


def pass_insert_secret(path, secret_store=None):
    command_run_interactive(['pass', 'insert', path], pass_env(secret_store))


def pass_get_secret(path, secret_store=None):
    exitcode, stdout, _ = command_exec(['pass', path], pass_env(secret_store))
    if exitcode == 0:
        return stdout.strip()
    else:
        return None


def pass_has_secret(path, secret_store=None):
    return pass_get_secret(path, secret_store) is not None
